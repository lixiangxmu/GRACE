# GRACE: Generating Cause and Effect of Disaster Sub-Events from Social Media Text

## Video url: https://youtu.be/qPA9aqIJOXg
